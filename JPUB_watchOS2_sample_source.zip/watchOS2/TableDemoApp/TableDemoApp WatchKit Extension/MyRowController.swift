//
//  MyRowController.swift
//  TableDemoApp
//
//  Created by Neil Smyth on 8/18/15.
//  Copyright © 2015 eBookFrenzy. All rights reserved.
//

import WatchKit

class MyRowController: NSObject {

    @IBOutlet var myImage: WKInterfaceImage!
    @IBOutlet var myLabel: WKInterfaceLabel!
}
