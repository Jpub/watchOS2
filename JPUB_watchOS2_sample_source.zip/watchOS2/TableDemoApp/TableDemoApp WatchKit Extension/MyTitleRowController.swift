//
//  MyTitleRowController.swift
//  TableDemoApp
//
//  Created by Neil Smyth on 8/18/15.
//  Copyright © 2015 eBookFrenzy. All rights reserved.
//

import WatchKit

class MyTitleRowController: NSObject {

    @IBOutlet var titleLabel: WKInterfaceLabel!
}
